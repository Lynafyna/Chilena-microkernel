//! halt — shut down the system

pub fn run() {
    println!("Shutting down...");
    unsafe { crate::sys::syscall::syscall1(crate::sys::syscall::number::HALT, 0xDEAD); }
}
