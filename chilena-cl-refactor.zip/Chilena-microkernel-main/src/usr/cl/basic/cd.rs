//! cd — change working directory

use crate::sys;

pub fn run(args: &[&str]) {
    let path = args.first().copied().unwrap_or("/");
    sys::process::set_cwd(path);
}
