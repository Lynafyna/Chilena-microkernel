//! clear — clear the screen

pub fn run() {
    print!("\x1b[2J\x1b[H");
}
