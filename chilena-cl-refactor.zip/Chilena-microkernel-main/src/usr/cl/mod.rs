//! cl — Chilena command line utilities

pub mod basic;
pub mod fs;
pub mod ipc;
pub mod system;
