//! help — display brief Chilena information

pub fn run() {
    println!("Chilena Kernel v{}", crate::VERSION);
    println!("A minimal x86_64 kernel written in Rust.");
}
