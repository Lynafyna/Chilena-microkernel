//! cl — Chilena command line utilities

pub mod shell;
pub mod basic;
pub mod fs;
pub mod ipc;
pub mod system;
